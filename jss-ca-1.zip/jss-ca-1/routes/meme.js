var express = require('express');
var router = express.Router();
// const { resolve } = require('path');
const axios = require('axios');

router.get('/', function (req, res, next) {});

module.exports = router;
