function open_new_window(location) {
  window.location.href = location;
}
